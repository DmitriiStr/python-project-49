# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.scripts']

package_data = \
{'': ['*'],
 'brain_games.scripts': ['.idea/.gitignore',
                         '.idea/.gitignore',
                         '.idea/.gitignore',
                         '.idea/.gitignore',
                         '.idea/.gitignore',
                         '.idea/.gitignore',
                         '.idea/.name',
                         '.idea/.name',
                         '.idea/.name',
                         '.idea/.name',
                         '.idea/.name',
                         '.idea/.name',
                         '.idea/inspectionProfiles/*',
                         '.idea/misc.xml',
                         '.idea/misc.xml',
                         '.idea/misc.xml',
                         '.idea/misc.xml',
                         '.idea/misc.xml',
                         '.idea/misc.xml',
                         '.idea/modules.xml',
                         '.idea/modules.xml',
                         '.idea/modules.xml',
                         '.idea/modules.xml',
                         '.idea/modules.xml',
                         '.idea/modules.xml',
                         '.idea/scripts.iml',
                         '.idea/scripts.iml',
                         '.idea/scripts.iml',
                         '.idea/scripts.iml',
                         '.idea/scripts.iml',
                         '.idea/scripts.iml',
                         '.idea/vcs.xml',
                         '.idea/vcs.xml',
                         '.idea/vcs.xml',
                         '.idea/vcs.xml',
                         '.idea/vcs.xml',
                         '.idea/vcs.xml']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-games = brain_games.scripts.brain_games:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/DmitriiStr/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/DmitriiStr/python-project-49/actions)',
    'author': 'Progrok',
    'author_email': 'Dist812@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
